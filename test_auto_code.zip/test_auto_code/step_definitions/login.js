const { Given, When, Then } = require('@cucumber/cucumber');
const LoginPage = require('../pages/loginPage.js');
const loginPage = new LoginPage();
const { LOGIN_USERS } = require('../support/testData.js');

Given('I launch the MyDemoApp', async () => {
// lauch app
  const driver = await require('../support/appium.js').driver();
  await driver.pause(2000);
});

When('I enter "<username>" username and "<password>" password', async (username, password) => {
  try {	  
	await loginPage.clickAppDrawerIcon();
	await loginPage.clickLoginButton_1();
    await loginPage.enterUsername(username);
    await loginPage.enterPassword(password);
  } catch (error) {
    console.error("Error while entering username or password:", error);   
  }
});

When('I click the login button', async () => {
  try {
    await loginPage.clickLoginButton_2();
  } catch (error) {
    console.error("Error while clicking login button:", error);
  }
});

Then('I should see the appropriate message based on the login result for , "<username>" username and "<password>" password'', async () => {
	try {
	if(await loginPage.isLoggedInSuccessfull()){
		await expect('Login Successfull').toBeExisting();
		console.log('Login success for Credentials : '+username +" , "+password);
	}		
	else if(await loginPage.isLoggedInSuccessfull()){
		await expect('Login Failed').toBeExisting();
		console.log('Login Failed for Credentials : '+username +" , "+password);
	}}
	catch (error) {
		console.error("Error while validating login", error);
	}	
});
