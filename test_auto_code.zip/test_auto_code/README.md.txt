Prerequisites:
	Node.js and npm (or yarn) installed: https://nodejs.org/en
	Appium server installed: https://appium.io/docs/en/2.0/quickstart/install/
	An Android emulator or real device configured for Appium testing
	
Project Setup:
	Clone this repository or download the project files.
	Install required dependencies:
	
dependencies:
	npm install
	
Running the Tests:
	Make sure you've replaced all placeholders with  app-specific details.
	Start the Appium server if not already running.
	In terminal, navigate to the project directory.
	Run the tests:
	
	npx wdio run features/*