const { Capabilities } = require('wdio-appium-service');

const capabilities = {
    platformName: 'android',
    app: '/support/Android-MyDemoAppRN.1.3.0.build-244.apk'
	deviceName: 'Pixel_4_API_30', // device name
	platformVersion: '11', // target Android version
	automationName: 'UiAutomator2',
	newCommandTimeout: 10, // 10 seconds timeout for new commands
	noReset: true, // Avoid resetting app state between tests
};

exports.driver = async () => {
    const service = await appium.launch({ capabilities });
    return service.session;
};
