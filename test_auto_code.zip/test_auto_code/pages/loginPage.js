const { element, by } = require('webdriverio');

class LoginPage {
    constructor() {
		//I am assuming all the elements having id property and using that
		this.appDrawerIcon = element(by.id('com.mydemoapp.package:id/appDrawerIcon'));
		this.loginButton1 = element(by.id('com.mydemoapp.package:id/loginButton1'));
        this.usernameField = element(by.id('com.mydemoapp.package:id/usernameField'));
        this.passwordField = element(by.id('com.mydemoapp.package:id/passwordField')); 
        this.loginButton2 = element(by.id('com.mydemoapp.package:id/loginButton2')); 
		this.loginSuccessMessage = element(by.id('com.mydemoapp.package:id/loginSuccessMessage')); 
		this.loginFailedMessage = element(by.id('com.mydemoapp.package:id/loginFailedMessage')); 
    }
	
	async clickAppDrawerIcon() {
		try{
			await this.appDrawerIcon.click();
		}
		catch (error) {
			console.error("Error while clicking appDrawerIcon button:", error);
		}        
    }
	async clickLoginButton_1() {
		try{
			await this.loginButton1.click();
		}
		catch (error) {
			console.error("Error while clicking loginButton1 button:", error);
		}        
    }
    async enterUsername(username) {
		try{
			await this.usernameField.setValue(username);
		}
		catch (error) {
			console.error("Error while entering value to usename field :", error);
		}	
    }

    async enterPassword(password) {        
		try{
			await this.passwordField.setValue(password);
		}
		catch (error) {
			console.error("Error while  entering value to password field ", error);
		}
    }

    async clickLoginButton_2() {
		try{
			await this.loginButton2.click();
		}
		catch (error) {
			console.error("Error while clicking loginButton2 :", error);
		}        
    }
	
	async isLoggedInSuccessfull() {
		try{
			return await this.loginSuccessMessage.isDisplayed();
		}
		catch (error) {
			console.error("Error while login validation :", error);
		}		
	}
	async isLoggedInFailed() {
		try{
			return await this.loginFailedMessage.isDisplayed();
		}
		catch (error) {
			console.error("Error while login validation :", error);
		}		
	}
}

module.exports = LoginPage;
