describe('Login',()=>{
   
it('Login Test for MyDemoApp', async ()=>{
    const dwawer=await $('//android.view.ViewGroup[@content-desc="open menu"]/android.widget.ImageView');
    const login1=await $('//android.widget.TextView[@text="Log In"]');
    const userName=await $('//android.widget.EditText[@content-desc="Username input field"]');
    const password=await $('//android.widget.EditText[@content-desc="Password input field"]');
    const signIn=await $('(//android.widget.TextView[@text="Login"])[2]');
    const lockedError=await $('//android.widget.TextView[@text="Sorry, this user has been locked out."]');
    const noMatchError=await $('//android.widget.TextView[@text="Provided credentials do not match any user in this service."]');
    const noCredentilasError=await $('//android.widget.TextView[@text="Username is required"]');
    const noPasswordError=await $('//android.widget.TextView[@text="Password is required"]');
    const successLogin=await $('//android.widget.TextView[@text="Products"]');
    
    
    //Test 1: Locked Credentials
    await dwawer.click();
    await login1.click();
    await userName.setValue('alice@example.com');
    await password.setValue('10203040');
    await signIn.click();
    await expect(lockedError).toHaveText('Sorry, this user has been locked out.');

    //Test 2: No Match Credentials
    await userName.setValue('1@2.com');
    await password.setValue('f-o-o');
    await signIn.click();
    await expect(noMatchError).toHaveText('Provided credentials do not match any user in this service.');

    //Test 3: Empty Credentials
    await userName.setValue('');
    await password.setValue('');
    await signIn.click();
    await expect(noCredentilasError).toHaveText('Username is required');

    //Test 4 : No Password
    await userName.setValue('bob@example.com');
    await password.setValue('');
    await signIn.click();
    await expect(noPasswordError).toHaveText('Password is required');

    //Test 5:Standard Valid Credentials
    await userName.setValue('bob@example.com');
    await password.setValue('10203040');
    await signIn.click();
    await expect(successLogin).toBeExisting(); 
})
})